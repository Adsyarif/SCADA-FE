module.exports = {

"[project]/src/views/attendance/components/map/map.tsx [ssr] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "server/chunks/ssr/[root of the server]__93aaaba5._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/views/attendance/components/map/map.tsx [ssr] (ecmascript, next/dynamic entry)");
    });
});
}}),

};