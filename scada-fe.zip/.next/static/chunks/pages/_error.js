__turbopack_load_page_chunks__("/_error", [
  "static/chunks/[root of the server]__57f0e368._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_beb00741._.js",
  "static/chunks/[root of the server]__ca38f087._.js",
  "static/chunks/src_pages__error_5771e187._.js",
  "static/chunks/src_pages__error_fce41f88._.js"
])
