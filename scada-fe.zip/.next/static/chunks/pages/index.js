__turbopack_load_page_chunks__("/", [
  "static/chunks/[root of the server]__a768c814._.js",
  "static/chunks/node_modules_next_ee6731c4._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_02ef09cd._.js",
  "static/chunks/node_modules_76cd370e._.js",
  "static/chunks/src_pages_index_5771e187._.js",
  "static/chunks/src_pages_index_f33e6b8c._.js"
])
