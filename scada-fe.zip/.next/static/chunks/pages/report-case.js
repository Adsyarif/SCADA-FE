__turbopack_load_page_chunks__("/report-case", [
  "static/chunks/src_views_attendance_components_map_map_tsx_3b50d563._.js",
  "static/chunks/[root of the server]__e2a4eda7._.js",
  "static/chunks/node_modules_next_b3b5f4f0._.js",
  "static/chunks/node_modules_react-dom_82bb97c6._.js",
  "static/chunks/node_modules_zod_lib_index_mjs_02ef09cd._.js",
  "static/chunks/node_modules_1e0ff34f._.js",
  "static/chunks/src_pages_user-role_index_tsx_5771e187._.js",
  "static/chunks/src_pages_user-role_index_tsx_349c0ae9._.js"
])
