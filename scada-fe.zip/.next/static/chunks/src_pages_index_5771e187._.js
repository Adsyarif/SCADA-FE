(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_index_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_index_5771e187._.js",
  "chunks": [
    "static/chunks/[root of the server]__5f839651._.js",
    "static/chunks/node_modules_next_ee6731c4._.js",
    "static/chunks/node_modules_react-dom_82bb97c6._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_02ef09cd._.js",
    "static/chunks/node_modules_76cd370e._.js"
  ],
  "source": "entry"
});
