(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_user-role_create_index_tsx_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_user-role_create_index_tsx_5771e187._.js",
  "chunks": [
    "static/chunks/src_views_attendance_components_map_map_tsx_a5eadf1b._.js",
    "static/chunks/[root of the server]__71b142de._.js",
    "static/chunks/node_modules_next_dist_compiled_6971397a._.js",
    "static/chunks/node_modules_next_dist_shared_lib_1250b3d1._.js",
    "static/chunks/node_modules_next_dist_client_2b75ce86._.js",
    "static/chunks/node_modules_next_dist_b512dcca._.js",
    "static/chunks/node_modules_next_301a4eb6._.js",
    "static/chunks/node_modules_react-dom_82bb97c6._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_02ef09cd._.js",
    "static/chunks/node_modules_axios_lib_9aa2336a._.js",
    "static/chunks/node_modules_ee8f05d9._.js"
  ],
  "source": "entry"
});
