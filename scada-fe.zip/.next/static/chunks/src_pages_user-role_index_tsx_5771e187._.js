(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_pages_user-role_index_tsx_5771e187._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_pages_user-role_index_tsx_5771e187._.js",
  "chunks": [
    "static/chunks/src_views_attendance_components_map_map_tsx_e4386890._.js",
    "static/chunks/[root of the server]__0afec789._.js",
    "static/chunks/node_modules_next_dist_compiled_6971397a._.js",
    "static/chunks/node_modules_next_dist_shared_lib_7ab6b823._.js",
    "static/chunks/node_modules_next_dist_client_2b75ce86._.js",
    "static/chunks/node_modules_next_dist_b512dcca._.js",
    "static/chunks/node_modules_next_5da9b3c9._.js",
    "static/chunks/node_modules_react-dom_82bb97c6._.js",
    "static/chunks/node_modules_zod_lib_index_mjs_02ef09cd._.js",
    "static/chunks/node_modules_axios_lib_9aa2336a._.js",
    "static/chunks/node_modules_441b05d1._.js"
  ],
  "source": "entry"
});
