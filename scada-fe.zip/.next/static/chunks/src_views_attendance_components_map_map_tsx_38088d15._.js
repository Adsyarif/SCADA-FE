(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/src_views_attendance_components_map_map_tsx_38088d15._.js", {

"[project]/src/views/attendance/components/map/map.tsx [client] (ecmascript, next/dynamic entry, async loader)": ((__turbopack_context__) => {

var { g: global, d: __dirname } = __turbopack_context__;
{
__turbopack_context__.v((parentImport) => {
    return Promise.all([
  "static/chunks/node_modules_d7a72282._.js",
  "static/chunks/src_views_attendance_components_map_map_tsx_82179c24._.js",
  "static/chunks/src_views_attendance_components_map_map_tsx_2c2bc5f7._.js"
].map((chunk) => __turbopack_context__.l(chunk))).then(() => {
        return parentImport("[project]/src/views/attendance/components/map/map.tsx [client] (ecmascript, next/dynamic entry)");
    });
});
}}),
}]);