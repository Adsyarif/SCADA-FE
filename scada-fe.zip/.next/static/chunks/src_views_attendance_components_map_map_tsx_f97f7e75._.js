(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_views_attendance_components_map_map_tsx_f97f7e75._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_views_attendance_components_map_map_tsx_f97f7e75._.js",
  "chunks": [
    "static/chunks/node_modules_d7a72282._.js",
    "static/chunks/src_views_attendance_components_map_map_tsx_82179c24._.js"
  ],
  "source": "dynamic"
});
