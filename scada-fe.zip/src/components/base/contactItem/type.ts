export type itemType = "operator" | "contact" | "message";
