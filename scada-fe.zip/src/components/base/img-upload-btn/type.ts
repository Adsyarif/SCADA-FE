
export type ImageUploadProps = {
    onChange?: (event: React.ChangeEvent<HTMLInputElement>) => void;
    accept?: string;
    multiple?: boolean;
}