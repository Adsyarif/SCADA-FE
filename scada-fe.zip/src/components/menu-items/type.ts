import React from "react"

export type MenuItemsProps = {
    href: string
    children: React.ReactNode
    menuName: string
}