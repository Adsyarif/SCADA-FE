export type ScheduleListProps = {
    day: string;
    date: string;
    time: string;
    shiftTime?: string[];
    onSchedule?: boolean;

}