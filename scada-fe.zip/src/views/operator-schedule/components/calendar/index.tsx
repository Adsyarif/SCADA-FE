export function CalendarSchedule() {
    return (
        <div>
            <span>Month</span>
        </div>
    )
}