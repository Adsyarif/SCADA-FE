export interface ReportCategoriesInterface {
  data: ReportCategory[];
}

export interface ReportCategory {
  categoryId: string;
  categoryName: string;
}
