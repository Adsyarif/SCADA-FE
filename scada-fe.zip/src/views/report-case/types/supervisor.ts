export interface SupervisorsInterface {
  data: SupervisorInterface[];
}

export interface SupervisorInterface {
  categoryId: string;
  categoryName: string;
}
