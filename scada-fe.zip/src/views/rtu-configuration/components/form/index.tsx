import React from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import "leaflet/dist/leaflet.css";
import axiosInstance from "@/api/axiosClient";

const MapContainer = dynamic(
  () => import("react-leaflet").then((mod) => mod.MapContainer),
  { ssr: false }
);
const TileLayer = dynamic(
  () => import("react-leaflet").then((mod) => mod.TileLayer),
  { ssr: false }
);
const Marker = dynamic(
  () => import("react-leaflet").then((mod) => mod.Marker),
  { ssr: false }
);
const Circle = dynamic(
  () => import("react-leaflet").then((mod) => mod.Circle),
  { ssr: false }
);

const rtuSchema = z.object({
  id: z.string().optional(),
  rtuName: z.string().min(1, "Name is required"),
  latitude: z.number(),
  longitude: z.number(),
  radius: z.number().positive("Radius must be positive"),
});
export type RtuFormData = z.infer<typeof rtuSchema>;

interface RtuFormProps {
  initialData?: RtuFormData & { id?: string };
}

export function RtuConfigurationForm({ initialData }: RtuFormProps) {
  const router = useRouter();
  const qc = useQueryClient();
  const isEdit = Boolean(initialData?.id);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<RtuFormData>({
    resolver: zodResolver(rtuSchema),
    defaultValues:
      initialData || {
        rtuName: "",
        latitude: -6.2,
        longitude: 106.8,
        radius: 500,
      },
  });

  const latitude = watch("latitude");
  const longitude = watch("longitude");
  const radius = watch("radius");

  const mutation = useMutation(
    (data: RtuFormData) =>
      isEdit && initialData?.id
        ? axiosInstance.put(`/rtu-configuration/${initialData.id}`, data)
        : axiosInstance.post("/rtu-configuration", data),
    {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: ["rtu-configurations"] });
        router.push("/rtu-configuration");
      },
    }
  );

  const onSubmit = (data: RtuFormData) => mutation.mutate(data);

  const handleMapClick = (e: any) => {
    setValue("latitude", e.latlng.lat);
    setValue("longitude", e.latlng.lng);
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4 p-4">
      <div>
        <label className="block font-medium">RTU Name</label>
        <input
          {...register("rtuName")}
          className="border p-2 rounded w-full"
        />
        {errors.rtuName && (
          <p className="text-red-600">{errors.rtuName.message}</p>
        )}
      </div>
      <div style={{ height: 300 }}>
        <MapContainer
          center={[latitude, longitude]}
          zoom={13}
          whenCreated={(map) => map.on("click", handleMapClick)}
        >
          <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" />
          <Marker position={[latitude, longitude]} />
          <Circle center={[latitude, longitude]} radius={radius} />
        </MapContainer>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div>
          <label className="block font-medium">Latitude</label>
          <input
            {...register("latitude", { valueAsNumber: true })}
            className="border p-2 rounded w-full"
            readOnly
          />
        </div>
        <div>
          <label className="block font-medium">Longitude</label>
          <input
            {...register("longitude", { valueAsNumber: true })}
            className="border p-2 rounded w-full"
            readOnly
          />
        </div>
      </div>
      <div>
        <label className="block font-medium">Radius (meters)</label>
        <input
          {...register("radius", { valueAsNumber: true })}
          type="number"
          className="border p-2 rounded w-full"
        />
        {errors.radius && (
          <p className="text-red-600">{errors.radius.message}</p>
        )}
      </div>
      <button
        type="submit"
        className="bg-blue-600 text-white px-4 py-2 rounded"
        disabled={mutation.isLoading}
      >
        {isEdit ? "Update RTU" : "Create RTU"}
      </button>
    </form>
  );
}
