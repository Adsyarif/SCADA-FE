import { PlusIcon } from "lucide-react";
import { useRouter } from "next/navigation";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import axiosInstance from "@/api/axiosClient";
import { RtuList } from "@/components/rtu-list";
import { Title } from "@/components";

interface RtuConfiguration {
  id: string;
  rtuName: string;
  latitude: number;
  longitude: number;
  radius: number;
}

export function RtuConfigurationWrapper() {
  const router = useRouter();
  const qc = useQueryClient();

  const { data, isLoading } = useQuery<RtuConfiguration[]>({
    queryKey: ["rtu-configurations"],
    queryFn: () => axiosInstance.get("/rtu-configuration").then((res) => res.data),
  });

  const deleteMutation = useMutation<void, Error, string>({
    mutationFn: (id: string) =>
      axiosInstance.delete(`/rtu-configuration/${id}`).then(() => {}),
    onSuccess: () => qc.invalidateQueries({ queryKey: ['rtu-configurations'] }),
  });

  const handleAdd = () => router.push("/rtu-configuration/create");
  const handleEdit = (id: string) => router.push(`/rtu-configuration/${id}/edit`);
  const handleDelete = (id: string) => {
    if (confirm("Are you sure you want to delete this RTU?")) {
      deleteMutation.mutate(id);
    }
  };

  return (
    <div className="w-full">
      <div>
        <Title isButton text="RTU Configuration" />
        <div className="px-4">
          <div className="flex justify-end items-center mb-4">
            <button
              onClick={handleAdd}
              className="px-2 py-1 rounded-md bg-blue-500 hover:bg-blue-700 text-white flex items-center gap-2"
            >
              <PlusIcon size={16} />
              Add
            </button>
          </div>
        </div>
         {data?.map((rtu) => (
            <RtuList
              key={rtu.id}
              rtuName={rtu.rtuName}
              rtuRadius={rtu.radius}
              rtuCoordinates={`${rtu.latitude}, ${rtu.longitude}`}
              onEdit={() => handleEdit(rtu.id)}
              onDelete={() => handleDelete(rtu.id)}
              isLoading={isLoading}
            />
          ))}

          {data?.length === 0 && !isLoading && (
            <div className="text-center text-gray-500">No RTUs found.</div>
          )}
      </div>
    </div>
  );
}
