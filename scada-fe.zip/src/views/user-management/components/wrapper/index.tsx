
export function UserManagementWrapper() {
    return (
        <div>
            <h1>ini isi User Management</h1>
        </div>
    )
}